array = [
  [7,0,11,15],
  [3,5,8,6],
  [12,15,89,99],
  [10000,10001,99,1]
]

array.forEach(array1=>{
  array1.forEach(hasil=>{
    if(hasil>array1[0]&&hasil>array1[1]&&hasil>array1[2]){
    console.log(hasil)
    } else if(hasil>array1[0]&&hasil>array1[1]&&hasil>array1[3]){
      console.log(hasil)  
    } else if(hasil>array1[0]&&hasil>array1[2]&&hasil>array1[3]){
      console.log(hasil)  
    } else if(hasil>array1[1]&&hasil>array1[1]&&hasil>array1[3]){
      console.log(hasil)  
    }
  })
})




