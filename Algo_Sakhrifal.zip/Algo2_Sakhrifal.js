arrayGroup = [1,2,3,4,5,6]
console.log('---Ini adalah arrayGroupPertama---')
batasGroupPertama = 2
for(i=0;i<arrayGroup.length;i++){
  if(i%2===0){
    e=i+batasGroupPertama
    console.log('index awal:',i)
    console.log('batas:',e)
    
    for(s=i;s<e;s++){
      console.log(arrayGroup[s])
    }
    
  }
}

console.log('---Ini adalah arrayGroupKedua---')
batasGroupKedua = 3
for(i=0;i<arrayGroup.length;i++){
  if(i%3===0){
    e=i+batasGroupKedua
    console.log('index awal:',i)
    console.log('batas:', e)
    for(s=i;s<e;s++){
      console.log(arrayGroup[s])
    }
    
  }
}

console.log('---Ini adalah arrayGroupKetiga---')
batasGroupKetiga = 4
for(i=0;i<arrayGroup.length;i++){
  if(i%4===0){
    e=i+batasGroupKetiga
    console.log('index awal:',i)
    if(e>arrayGroup.length){
      e=arrayGroup.length
    }
    console.log('batas:',e)
    
    for(s=i;s<e;s++){
      console.log(arrayGroup[s])
    }
    
  }
}
